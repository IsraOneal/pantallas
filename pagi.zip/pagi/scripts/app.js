/* =====================================================
   RED MESH — SCRIPTS PRINCIPALES
   Toda la lógica de navegación y funcionalidad
   ===================================================== */

/* ---- ESTADO ---- */
let currentScreen = 'screen-splash';
let meshMode = false;
let regStep = 0;
let forgotStep = 0;

/* ---- NAVEGACIÓN ---- */
function goTo(id) {
  if (id === currentScreen) return;
  document.getElementById(currentScreen).classList.remove('active');
  document.getElementById(id).classList.add('active');
  currentScreen = id;
  const b = document.getElementById(id).querySelector('.screen-body,.auth-screen-body');
  if (b) b.scrollTop = 0;
}

function navTo(section) {
  const map = {
    dashboard: 'screen-dashboard',
    map:       'screen-map',
    routes:    'screen-routes',
    alerts:    'screen-alerts',
    bluetooth: 'screen-bluetooth',
    profile:   'screen-profile'
  };
  if (map[section]) goTo(map[section]);
}

function goToRoutes(routeName) {
  goTo('screen-routes');
  if (routeName) showRouteDetail();
}

/* ---- SPLASH ---- */
setTimeout(() => goTo('screen-login'), 2200);

/* ---- LOGIN ---- */
function doLogin() {
  const btn = document.getElementById('login-btn');
  btn.innerHTML = '<div class="spinner"></div>';
  btn.disabled = true;
  setTimeout(() => {
    btn.innerHTML = 'Entrar';
    btn.disabled = false;
    goTo('screen-dashboard');
  }, 1200);
}

/* ---- REGISTRO ---- */
function regNext() {
  if (regStep === 0) {
    regStep = 1;
    document.getElementById('reg-s0').style.display = 'none';
    document.getElementById('reg-s1').style.display = 'block';
    document.getElementById('reg-progress').style.width = '66%';
    document.getElementById('rl0').style.color = 'var(--text-ph)';
    document.getElementById('rl1').style.color = 'var(--blue-cta)';
    startResendTimer();
  } else if (regStep === 1) {
    regStep = 2;
    document.getElementById('reg-s1').style.display = 'none';
    document.getElementById('reg-s2').style.display = 'block';
    document.getElementById('reg-progress').style.width = '100%';
    document.getElementById('rl1').style.color = 'var(--text-ph)';
    document.getElementById('rl2').style.color = 'var(--blue-cta)';
  }
}

function regBack() {
  if (regStep === 0) { goTo('screen-login'); return; }
  if (regStep === 1) {
    regStep = 0;
    document.getElementById('reg-s1').style.display = 'none';
    document.getElementById('reg-s0').style.display = 'block';
    document.getElementById('reg-progress').style.width = '33%';
    document.getElementById('rl1').style.color = 'var(--text-ph)';
    document.getElementById('rl0').style.color = 'var(--blue-cta)';
  } else if (regStep === 2) {
    regStep = 1;
    document.getElementById('reg-s2').style.display = 'none';
    document.getElementById('reg-s1').style.display = 'block';
    document.getElementById('reg-progress').style.width = '66%';
    document.getElementById('rl2').style.color = 'var(--text-ph)';
    document.getElementById('rl1').style.color = 'var(--blue-cta)';
  }
}

function regComplete() {
  document.getElementById('reg-s2').style.display = 'none';
  document.getElementById('reg-success').style.display = 'block';
}

function checkUser(el) {
  const hint  = document.getElementById('user-hint');
  const check = document.getElementById('user-check');
  if (el.value.length < 3) { hint.textContent = ''; check.style.display = 'none'; return; }
  check.style.display = 'flex';
  const taken = el.value === 'juangarcia';
  hint.textContent = taken ? '⚠️ Nombre de usuario ya en uso' : '✓ Disponible';
  hint.style.color  = taken ? 'var(--amber)' : 'var(--green)';
}

let resendInt;
function startResendTimer() {
  let t = 60;
  const btn = document.getElementById('resend-btn');
  btn.style.color = 'var(--text-ph)';
  resendInt = setInterval(() => {
    t--;
    btn.textContent = `Reenviar (${t}s)`;
    if (t <= 0) {
      clearInterval(resendInt);
      btn.textContent = 'Reenviar código';
      btn.style.color = 'var(--blue-cta)';
    }
  }, 1000);
}

/* ---- RECUPERAR CONTRASEÑA ---- */
let forgotTimerInt;

function forgotNext() {
  if (forgotStep === 0) {
    forgotStep = 1;
    document.getElementById('forgot-s0').style.display = 'none';
    document.getElementById('forgot-s1').style.display = 'block';
    document.getElementById('forgot-progress').style.width = '66%';
    startForgotTimer();
  } else if (forgotStep === 1) {
    forgotStep = 2;
    document.getElementById('forgot-s1').style.display = 'none';
    document.getElementById('forgot-s2').style.display = 'block';
    document.getElementById('forgot-progress').style.width = '100%';
  }
}

function forgotComplete() {
  document.getElementById('forgot-s2').style.display = 'none';
  document.getElementById('forgot-success').style.display = 'block';
}

function startForgotTimer() {
  let t = 60;
  const el = document.getElementById('forgot-timer');
  forgotTimerInt = setInterval(() => {
    t--;
    el.textContent = t > 0 ? `Reenviar en ${t}s` : 'Reenviar código';
    if (t <= 0) {
      clearInterval(forgotTimerInt);
      el.style.color  = 'var(--blue-cta)';
      el.style.cursor = 'pointer';
    }
  }, 1000);
}

/* ---- OTP ---- */
function handleOtp(input) {
  const v = String(input.value).slice(0, 6);
  for (let i = 0; i < 6; i++) {
    const c = document.getElementById('otp' + i);
    if (c) {
      c.textContent = v[i] || '-';
      c.className = 'otp-cell' + (v[i] ? ' filled' : '') + (i === v.length ? ' active' : '');
    }
  }
  input.value = v;
}

/* ---- TOGGLE PASSWORD ---- */
function togglePass(id, btn) {
  const inp = document.getElementById(id);
  if (!inp) return;
  inp.type = inp.type === 'password' ? 'text' : 'password';
  btn.style.opacity = inp.type === 'text' ? '1' : '0.5';
}

/* ---- MODO MESH (demo) ---- */
function toggleMeshMode() {
  meshMode = !meshMode;
  document.getElementById('conn-card-internet').style.display = meshMode ? 'none' : 'block';
  document.getElementById('conn-card-mesh').style.display     = meshMode ? 'block' : 'none';
}

/* ---- BÚSQUEDA ---- */
function openSearch() {
  const overlay = document.getElementById('search-overlay');
  if (overlay) {
    overlay.classList.add('open');
    setTimeout(() => {
      const inp = document.getElementById('search-input');
      if (inp) inp.focus();
    }, 100);
  }
}

function closeSearch() {
  const overlay = document.getElementById('search-overlay');
  if (overlay) overlay.classList.remove('open');
}

function selectDest(dest) {
  closeSearch();
  const d = document.getElementById('route-dest');
  if (d) d.value = dest;
  goTo('screen-routes');
  searchRoutes();
}

/* ---- MODALES ---- */
function openModal(id)  { document.getElementById(id).classList.add('open'); }
function closeModal(id) { document.getElementById(id).classList.remove('open'); }

document.addEventListener('click', e => {
  if (e.target.classList.contains('modal-overlay')) {
    e.target.classList.remove('open');
  }
});

document.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    document.querySelectorAll('.modal-overlay.open').forEach(m => m.classList.remove('open'));
    const so = document.getElementById('search-overlay');
    if (so && so.classList.contains('open')) so.classList.remove('open');
  }
});

/* ---- RUTAS ---- */
function searchRoutes() {
  const r = document.getElementById('route-results');
  if (r) r.style.display = 'block';
}

function swapOD() {
  const o = document.getElementById('route-origin');
  const d = document.getElementById('route-dest');
  if (!o || !d) return;
  const tmp = o.value;
  o.value = d.value;
  d.value = tmp;
}

function loadRoute(from, to) {
  const o = document.getElementById('route-origin');
  const d = document.getElementById('route-dest');
  if (o) o.value = from;
  if (d) d.value = to;
  searchRoutes();
}

function showRoutesSearch() {
  ['search','detail','comments','map'].forEach(s => {
    document.getElementById('routes-subview-' + s).style.display = 'none';
  });
  document.getElementById('routes-subview-search').style.display = 'flex';
  document.getElementById('routes-subview-nav').style.display    = 'none';
}

function showRouteDetail() {
  ['search','comments','map'].forEach(s => {
    document.getElementById('routes-subview-' + s).style.display = 'none';
  });
  document.getElementById('routes-subview-detail').style.display = 'flex';
  document.getElementById('routes-subview-nav').style.display    = 'none';
}

function showRouteComments() {
  ['search','detail','map'].forEach(s => {
    document.getElementById('routes-subview-' + s).style.display = 'none';
  });
  document.getElementById('routes-subview-comments').style.display = 'flex';
}

function showRouteMap() {
  ['search','detail','comments'].forEach(s => {
    document.getElementById('routes-subview-' + s).style.display = 'none';
  });
  document.getElementById('routes-subview-map').style.display = 'flex';
  document.getElementById('routes-subview-nav').style.display = 'none';
}

function showNavMode() {
  document.getElementById('routes-subview-nav').style.display = 'block';
}

/* ---- ALERTAS ---- */
const alertData = [
  {
    icon: `<div style="width:64px;height:64px;background:rgba(245,158,11,.1);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto;border:2px solid rgba(245,158,11,.25)"><svg viewBox="0 0 24 24" style="width:32px;height:32px;stroke:var(--amber);fill:none;stroke-width:2"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg></div>`,
    title: 'Desvío en Av. 20 de Noviembre',
    badge: '<span class="badge badge-amber">Alta prioridad</span>',
    body: `<div style="display:flex;gap:10px;padding:12px;background:var(--input-bg);border-radius:var(--r-sm);border:1.5px solid var(--border)"><div style="font-size:13px;color:var(--text-sec);line-height:1.5">Obras en la esquina con Francisco I. Madero. El camión toma Cinco de Febrero hasta retomar la ruta en Ángel Flores.</div></div>
           <div style="display:flex;gap:10px;align-items:center;padding:12px;background:var(--input-bg);border-radius:var(--r-sm);border:1.5px solid var(--border)"><span style="font-size:13px;color:var(--text-sec)">📍 Ruta 7 · Av. 20 de Noviembre km 2</span></div>
           <div style="display:flex;gap:10px;align-items:center;padding:12px;background:var(--input-bg);border-radius:var(--r-sm);border:1.5px solid var(--border)"><span style="font-size:13px;color:var(--text-sec)">🕐 Hoy · 14:05 hrs</span></div>`
  },
  {
    icon: `<div style="width:64px;height:64px;background:rgba(248,113,113,.1);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto;border:2px solid rgba(248,113,113,.25)"><svg viewBox="0 0 24 24" style="width:32px;height:32px;stroke:var(--red);fill:none;stroke-width:2"><circle cx="12" cy="12" r="10"/><polyline points="12,6 12,12 16,14"/></svg></div>`,
    title: 'Retraso de 15 minutos · Ruta 3',
    badge: '<span class="badge badge-red">Alta prioridad</span>',
    body: `<div style="display:flex;gap:10px;padding:12px;background:var(--input-bg);border-radius:var(--r-sm);border:1.5px solid var(--border)"><div style="font-size:13px;color:var(--text-sec);line-height:1.5">Tráfico pesado en el acceso norte. Se estima normalización en 30 min.</div></div>
           <div style="display:flex;gap:10px;align-items:center;padding:12px;background:var(--input-bg);border-radius:var(--r-sm);border:1.5px solid var(--border)"><span style="font-size:13px;color:var(--text-sec)">📍 Ruta 3 · Acceso Norte</span></div>
           <div style="display:flex;gap:10px;align-items:center;padding:12px;background:var(--input-bg);border-radius:var(--r-sm);border:1.5px solid var(--border)"><span style="font-size:13px;color:var(--text-sec)">🕐 Hoy · 13:52 hrs</span></div>`
  },
  {
    icon: `<div style="width:64px;height:64px;background:rgba(167,139,250,.1);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto;border:2px solid rgba(167,139,250,.25)"><svg viewBox="0 0 24 24" style="width:32px;height:32px;stroke:var(--mesh-purple);fill:none;stroke-width:2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg></div>`,
    title: 'Parada Mercado Gómez cerrada',
    badge: '<span class="badge badge-purple">Media prioridad</span>',
    body: `<div style="display:flex;gap:10px;padding:12px;background:var(--input-bg);border-radius:var(--r-sm);border:1.5px solid var(--border)"><div style="font-size:13px;color:var(--text-sec);line-height:1.5">Cierre temporal por festividades. Siguiente parada: Mercado Gómez Norte, a 200 m.</div></div>
           <div style="display:flex;gap:10px;align-items:center;padding:12px;background:var(--input-bg);border-radius:var(--r-sm);border:1.5px solid var(--border)"><span style="font-size:13px;color:var(--text-sec)">📍 Parada #42 · Centro Histórico</span></div>
           <div style="display:flex;gap:10px;align-items:center;padding:12px;background:var(--input-bg);border-radius:var(--r-sm);border:1.5px solid var(--border)"><span style="font-size:13px;color:var(--text-sec)">🕐 Hoy · 13:30 hrs</span></div>`
  }
];

function showAlertDetail(i) {
  const a = alertData[i];
  document.getElementById('alert-detail-icon').innerHTML  = a.icon;
  document.getElementById('alert-detail-title').textContent = a.title;
  document.getElementById('alert-detail-badge').innerHTML = a.badge;
  document.getElementById('alert-detail-body').innerHTML  = a.body;
  document.getElementById('alerts-list').style.display    = 'none';
  document.getElementById('alert-detail').style.display   = 'flex';
}

function hideAlertDetail() {
  document.getElementById('alert-detail').style.display = 'none';
  document.getElementById('alerts-list').style.display  = 'block';
}

/* ---- BLUETOOTH ---- */
function startScan() {
  document.getElementById('bt-idle').style.display = 'none';
  document.getElementById('bt-scanning').style.display = 'block';
  setTimeout(showDevicesList, 2000);
}

function showDevicesList() {
  document.getElementById('bt-scanning').style.display = 'none';
  document.getElementById('bt-devices').style.display  = 'block';
}

function connectDevice() {
  document.getElementById('bt-devices').style.display   = 'none';
  document.getElementById('bt-connected').style.display = 'block';
}

function showBtConnected() {
  document.getElementById('bt-idle').style.display      = 'none';
  document.getElementById('bt-connected').style.display = 'block';
}

function startTransfer(type) {
  document.getElementById('transfer-title').textContent  = type === 'receive' ? 'Recibiendo datos...' : 'Enviando datos...';
  document.getElementById('complete-title').textContent  = type === 'receive' ? '¡Datos recibidos!'  : '¡Datos enviados!';
  document.getElementById('complete-sub').textContent    = type === 'receive'
    ? 'Recibidos 8 reportes nuevos de rutas'
    : 'Datos enviados correctamente a María P.';

  document.getElementById('bt-connected').style.display    = 'none';
  document.getElementById('bt-transferring').style.display = 'block';

  let p = 0;
  const fill   = document.getElementById('transfer-fill');
  const pctEl  = document.getElementById('transfer-pct');
  const iv = setInterval(() => {
    p += 5;
    fill.style.width   = p + '%';
    pctEl.textContent  = p + '%';
    if (p >= 100) {
      clearInterval(iv);
      setTimeout(() => {
        document.getElementById('bt-transferring').style.display = 'none';
        document.getElementById('bt-complete').style.display     = 'block';
      }, 400);
    }
  }, 80);
}

function resetBt() {
  ['bt-complete','bt-connected','bt-scanning','bt-devices','bt-transferring'].forEach(id => {
    document.getElementById(id).style.display = 'none';
  });
  document.getElementById('bt-idle').style.display        = 'block';
  document.getElementById('transfer-fill').style.width    = '0%';
  document.getElementById('transfer-pct').textContent     = '0%';
}

/* ---- PERFIL ---- */
function goToProfileSub(sub) {
  goTo('screen-profile');
  const ids = ['main','travel','settings','edit-profile','history','permissions','notif-settings','privacy','help'];
  ids.forEach(id => {
    const el = document.getElementById('profile-' + id);
    if (el) el.style.display = (id === sub) ? 'flex' : 'none';
  });
}

function hideProfileSub() {
  goToProfileSub('main');
}

/* ---- CHIPS ---- */
function toggleChip(el) {
  el.classList.toggle('active');
}

/* ---- ACORDEÓN ---- */
function toggleAccordion(item) {
  item.classList.toggle('open');
}